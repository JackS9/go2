<?php
/*
 * Mysql Ajax Table Editor
 *
 * Copyright (c) 2014 Chris Kitchen <info@mysqlajaxtableeditor.com>
 * All rights reserved.
 *
 * See COPYING file for license information.
 *
 * Download the latest version from
 * http://www.mysqlajaxtableeditor.com
 */
require_once('DBC.php');
require_once('Common.php');
require_once('php/lang/LangVars-en.php');
require_once('php/AjaxTableEditor.php');
class UploadToDir extends Common
{
	protected $Editor;
	protected $dataDir = 'uploads/';
	protected $mateInstances = array('m2_');
	
	protected function displayHtml()
	{
		$html = '
			
			<br />
			
			<div class="mateAjaxLoaderDiv"><div id="ajaxLoader1"><img src="images/ajax_loader.gif" alt="Loading..." /></div></div>
			
			<br /><br />
			
			<div id="'.$this->mateInstances[0].'information">
			</div>
	
			<div id="mateTooltipErrorDiv" style="display: none;"></div>
			
			<div id="'.$this->mateInstances[0].'titleLayer" class="mateTitleDiv">
			</div>
			
			<div id="'.$this->mateInstances[0].'tableLayer" class="mateTableDiv">
			</div>
			
			<div id="'.$this->mateInstances[0].'updateInPlaceLayer" class="mateUpdateInPlaceDiv">
			</div>
			
			<div id="'.$this->mateInstances[0].'recordLayer" class="mateRecordLayerDiv">
			</div>		
			
			<div id="'.$this->mateInstances[0].'searchButtonsLayer" class="mateSearchBtnsDiv">
			</div>';
		
		echo $html;
			
		// Set default session configuration variables here
		$defaultSessionData['orderByColumn'] = 'first_name';

		$defaultSessionData = base64_encode($this->Editor->jsonEncode($defaultSessionData));
		
		$javascript = '	
			<script type="text/javascript">
				var ' . $this->mateInstances[0] . ' = new mate("' . $this->mateInstances[0] . '");
				' . $this->mateInstances[0] . '.setAjaxInfo({url: "' . $_SERVER['PHP_SELF'] . '", history: true});
				' . $this->mateInstances[0] . '.init("' . $defaultSessionData . '");
				
			</script>';
		echo $javascript;
	}
	
	public function formatFileSize($col,$size,$row)
	{
		$sizes = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
		$retstring = '%01.2f %s';
		$lastsizestring = end($sizes);
		foreach ($sizes as $sizestring) 
		{
				if ($size < 1024) { break; }
				if ($sizestring != $lastsizestring) { $size /= 1024; }
		}
		if ($sizestring == $sizes[0]) { $retstring = '%01d %s'; }
		return sprintf($retstring, $size, $sizestring);
	}
	
	public function formatImage($col,$val,$row)
	{
		$html = '';
		if(strlen($val) > 0)
		{
			$html .= '<a target="_blank" href="uploads/'.$val.'"><img style="border: none;" src="uploads/'.$val.'" alt="'.$val.'" width="100" /></a>';
		}
		return $html;
	}
	
	public function handleUpload($col,$id,$filesArr,$valErrors)
	{
		if(count($valErrors) == 0)
		{
			// Delete image file if the employee already had one
			$query = "select file_name from emp_upload_dir where id = :id";
			$queryParams = array('id' => $id);
			$stmt = DBC::get()->prepare($query);
			$stmt->execute($queryParams);
			if($row = $stmt->fetch())
			{
				if(strlen($row['file_name']) > 0)
				{
					unlink($this->dataDir.$row['file_name']);
				}
			}
			// Copy file to data directory and update database with the file name.
			if(move_uploaded_file($filesArr['tmp_name'],$this->dataDir.$filesArr['name']))
			{
				$query = "update emp_upload_dir set file_name = :file_name where id = :id";
				$queryParams = array('file_name' => $filesArr['name'], 'id' => $id);
				$stmt = DBC::get()->prepare($query);
				$result = $stmt->execute($queryParams);
				if(!$result)
				{
					$valErrors[] = 'There was an error updating the database.';
					unlink($this->dataDir.$filesArr['name']);
				}
			}
			else
			{
				$valErrros[] = 'The file could not be moved';
			}
		}
		return $valErrors;
	}
	
	public function deleteFile($info)
	{
		// code to delete file
		if(@unlink($this->dataDir.$info['uploadName']))
		{
			$query = "update emp_upload_dir set file_name = '' where id = :id limit 1";
			$queryParams = array('id' => $info['id']);
			$stmt = DBC::get()->prepare($query);
			$stmt->execute($queryParams);
			if($stmt->rowCount() > 0)
			{
				return true;
			}
		}
		$this->Editor->warnings[] = 'There was an error deleting the file.';
		return false;
	}
	
	public function testAfterDelete($id,$col,$row)
	{

	}
	
	protected function initiateEditor()
	{
		$tableColumns['id'] = array(
			'display_text' => 'ID', 
			'perms' => '', 
		);
		$tableColumns['first_name'] = array(
			'display_text' => 'First Name', 
			'perms' => 'EVCTAXQSFHO', 
			'req' => true, 
			'input_info' => 'size="10"'
		);
		$tableColumns['last_name'] = array(
			'display_text' => 'Last Name', 
			'perms' => 'EVCTAXQSFHO', 
			'val_fun' => array(&$this,'validateFun'), 
			'input_info' => 'size="10"'
		);
		$tableColumns['email'] = array(
			'display_text' => 'Email', 
			'perms' => 'EVCTAXQSFHO', 
			'textarea' => array('cols' => 20, 'rows' => 2)
		);
		$tableColumns['department'] = array(
			'display_text' => 'Department', 
			'perms' => 'EVCTAXQSFHO', 
			'select_array' => array(
				'Accounting' => 'Accounting', 
				'Marketing' => 'Marketing', 
				'Sales' => 'Sales', 
				'Production' => 'Production'
			),
		); 
		$tableColumns['file_name'] = array(
			'display_text' => 'Image', 
			'perms' => 'EVCAXTQSFHO',
			'file_upload' => array(
				'upload_fun' => array(&$this,'handleUpload'), 
				'delete_fun' => array(&$this,'deleteFile')), 
			'table_fun' => array(&$this,'formatImage'), 
			'view_fun' => array(&$this,'formatImage')
		);
		$tableColumns['hire_date'] = array(
			'display_text' => 'Hire Date', 
			'perms' => 'EVCTAXQSHO', 
			'display_mask' => 'date_format(hire_date,"%d %M %Y")', 
			'calendar' => array('js_format' => 'dd MM yy'),
			'col_header_info' => 'style="width: 200px;"', 
			'order_mask' => 'emp_upload_dir.hire_date',
			'range_mask' => 'emp_upload_dir.hire_date',
		); 

		$tableName = 'emp_upload_dir';
		$primaryCol = 'id';
		$errorFun = array(&$this,'logError');
		$permissions = 'EAVDCXHOUFIM';
		
		$this->Editor = new AjaxTableEditor($tableName,$primaryCol,$errorFun,$permissions,$tableColumns);
		$this->Editor->setConfig('tableInfo','cellpadding="1" width="1150" class="mateTable"');
		$this->Editor->setConfig('tableTitle','Upload To Directory');
		$this->Editor->setConfig('addRowTitle','Add Employee');
		$this->Editor->setConfig('editRowTitle','Edit Employee');
		$this->Editor->setConfig('paginationLinks',true);
		$this->Editor->setConfig('instanceName',$this->mateInstances[0]);
		//$this->Editor->setConfig('iconColPosition','first');
		$this->Editor->setConfig('filterPosition','top');
		$this->Editor->setConfig('editInPlace',true);
		$this->Editor->setConfig('addInPlace',true);
		$this->Editor->setConfig('afterDeleteFun',array(&$this,'testAfterDelete'));
		//$this->Editor->setConfig('viewQuery',true);
	}
	
	function __construct()
	{
		session_start();
		ob_start();
		$this->initiateEditor();
		if(isset($_POST['json']))
		{
			if(ini_get('magic_quotes_gpc'))
			{
				$_POST['json'] = stripslashes($_POST['json']);
			}
			$this->Editor->data = $this->Editor->jsonDecode($_POST['json'],true);
			$this->Editor->setDefaults();
			$this->Editor->main();
			//echo $this->Editor->jsonEncode($this->Editor->retArr);
		}
		else if(isset($_GET['mate_export']))
		{
			$this->Editor->data['sessionData'] = $_GET['session_data'];
			$this->Editor->setDefaults();
			ob_end_clean();
			header('Cache-Control: no-cache, must-revalidate');
			header('Pragma: no-cache');
			header('Content-type: application/x-msexcel');
			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="'.$this->Editor->tableName.'.csv"');
			// Add utf-8 signature for windows/excel
			echo chr(0xEF).chr(0xBB).chr(0xBF);
			echo $this->Editor->exportInfo();
			exit();
		}
		else
		{
			$this->displayHeaderHtml();
			$this->displayHtml();
			$this->displayFooterHtml();
		}
	}
}
$page = new UploadToDir();
?>